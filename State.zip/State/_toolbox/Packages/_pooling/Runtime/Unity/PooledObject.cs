﻿

namespace _t._pooling.Runtime.Unity;

public class PooledObject
{
    
}
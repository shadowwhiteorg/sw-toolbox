﻿namespace _t;

public class Class1
{
}
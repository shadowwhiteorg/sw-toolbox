﻿namespace _t.Shared.LFU;

public interface ILFUCache
{
    
}
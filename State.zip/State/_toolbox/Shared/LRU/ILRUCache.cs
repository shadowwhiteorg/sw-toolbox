﻿namespace _t.Shared.LRU;

public interface ILRUCache
{
    
}
﻿namespace _t.Shared.LRU;

public class FrequencyList
{
    
}